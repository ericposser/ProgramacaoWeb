package com.aula1.crud.Atividade.Repository;

import com.aula1.crud.Atividade.Model.Localizacao_dep;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocalizacaoDepRepository extends JpaRepository<Localizacao_dep, Long> {

}
