package com.aula1.crud.Atividade.Controller;

import com.aula1.crud.Atividade.Model.Trabalha_em;
import com.aula1.crud.Atividade.Repository.TrabalhaEmRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/trabalha_em")
public class TrabalhaEmController {
    @Autowired
    private TrabalhaEmRepository repository;

    @GetMapping
    public @ResponseBody List<Trabalha_em> listarTrabalhaEm() {
        return repository.findAll();
    }

    @PostMapping
    public @ResponseBody String salvarTrabalhaEm(@RequestBody Trabalha_em trabalhaEm) {
        repository.save(trabalhaEm);
        return "saved";
    }
}
