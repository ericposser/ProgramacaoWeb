package com.aula1.crud.Atividade.Controller;

import com.aula1.crud.Atividade.Model.Funcionario;
import com.aula1.crud.Atividade.Repository.FuncionarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/funcionario")
public class FuncionarioController {
    @Autowired
    private FuncionarioRepository repository;

    @GetMapping
    public @ResponseBody List<Funcionario> listarFuncionarios() {
        return repository.findAll();
    }

    @PostMapping
    public @ResponseBody String salvarFuncionario(@RequestBody Funcionario funcionario) {
        repository.save(funcionario);
        return "saved";
    }
}
