package com.aula1.crud.Atividade.Controller;

import com.aula1.crud.Atividade.Model.Dependente;
import com.aula1.crud.Atividade.Repository.DependenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/dependente")
public class DependenteController {
    @Autowired
    private DependenteRepository repository;

    @GetMapping
    public @ResponseBody List<Dependente> listarDependentes() {
        return repository.findAll();
    }

    @PostMapping
    public @ResponseBody String salvarDependente(@RequestBody Dependente dependente) {
        repository.save(dependente);
        return "saved";
    }
}
