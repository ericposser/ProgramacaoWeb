package com.aula1.crud.Atividade.Model;

import jakarta.persistence.*;

@Entity
public class Trabalha_em {
    private String horas;
    @Id
    @ManyToOne
    @JoinColumn(name = "Fcpf", nullable = false)
    private Funcionario tFuncionario;
    @Id
    @ManyToOne
    @JoinColumn(name = "Pnr", nullable = false)
    private Projeto tProjeto;

}
