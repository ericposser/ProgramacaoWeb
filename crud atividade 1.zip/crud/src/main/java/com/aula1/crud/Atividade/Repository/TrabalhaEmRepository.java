package com.aula1.crud.Atividade.Repository;

import com.aula1.crud.Atividade.Model.Trabalha_em;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrabalhaEmRepository extends JpaRepository<Trabalha_em, Long> {

}
