package com.aula1.crud.Atividade.Controller;

import com.aula1.crud.Atividade.Model.Departamento;
import com.aula1.crud.Atividade.Repository.DepartamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/departamento")
public class DepartamentoController {
    @Autowired
    private DepartamentoRepository repository;

    @GetMapping
    public @ResponseBody List<Departamento> listarDepartamentos() {
        return repository.findAll();
    }

    @PostMapping
    public @ResponseBody String salvarDepartamento(@RequestBody Departamento departamento) {
        repository.save(departamento);
        return "saved";
    }
}
