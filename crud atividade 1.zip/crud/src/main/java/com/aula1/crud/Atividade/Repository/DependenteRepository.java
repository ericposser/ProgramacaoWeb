package com.aula1.crud.Atividade.Repository;

import com.aula1.crud.Atividade.Model.Dependente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DependenteRepository extends JpaRepository<Dependente, Long> {

}
