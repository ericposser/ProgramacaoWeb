package com.aula1.crud.Atividade.Controller;

import com.aula1.crud.Atividade.Model.Projeto;
import com.aula1.crud.Atividade.Repository.ProjetoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/projeto")
public class ProjetoController {
    @Autowired
    private ProjetoRepository repository;

    @GetMapping
    public @ResponseBody List<Projeto> listarProjetos() {
        return repository.findAll();
    }

    @PostMapping
    public @ResponseBody String salvarProjeto(@RequestBody Projeto projeto) {
        repository.save(projeto);
        return "saved";
    }
}
