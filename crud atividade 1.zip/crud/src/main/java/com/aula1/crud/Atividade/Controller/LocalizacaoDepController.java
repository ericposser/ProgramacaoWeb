package com.aula1.crud.Atividade.Controller;

import com.aula1.crud.Atividade.Model.Localizacao_dep;
import com.aula1.crud.Atividade.Repository.LocalizacaoDepRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/localizacao_dep")
public class LocalizacaoDepController {
    @Autowired
    private LocalizacaoDepRepository repository;

    @GetMapping
    public @ResponseBody List<Localizacao_dep> listarLocalizacoesDep() {
        return repository.findAll();
    }

    @PostMapping
    public @ResponseBody String salvarLocalizacaoDep(@RequestBody Localizacao_dep localizacaoDep) {
        repository.save(localizacaoDep);
        return "saved";
    }
}
