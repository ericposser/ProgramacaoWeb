package com.aula1.crud.Atividade.Model;

import jakarta.persistence.*;

import java.util.Date;
import java.util.List;

@Entity
public class Funcionario {
    @Id
    private String cpf;

    @Embedded
    private Nome nome;
    private Date dataNasci;
    private String salario;
    private boolean sexo;
    private String endereco;

    @ManyToOne
    @JoinColumn(name = "cpf_supervisor")
    private Funcionario supervisor;

    @OneToMany(mappedBy = "tFuncionario", cascade = CascadeType.ALL)
    private List<Trabalha_em> projetosF;

    @OneToMany(mappedBy = "supervisor", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Funcionario> supervisionado;

    @OneToMany(mappedBy = "funcionarioDep", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Dependente> dependentes;

    @ManyToOne
    @JoinColumn(name = "departamento_id")
    private Departamento departamentoFuncionario;

}
