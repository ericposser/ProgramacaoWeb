package com.aula1.crud.Atividade.Repository;

import com.aula1.crud.Atividade.Model.Funcionario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FuncionarioRepository extends JpaRepository<Funcionario, Long> {

}
