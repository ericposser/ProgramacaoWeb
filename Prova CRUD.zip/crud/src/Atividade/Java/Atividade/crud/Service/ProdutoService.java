package Atividade.crud.Service;

import Atividade.crud.Model.Cliente;
import Atividade.crud.Model.Produto;
import Atividade.crud.Repository.ClienteRepository;
import Atividade.crud.Repository.ProdutoRepository;
import com.aula1.crud.Exception.ResourceNotFoundException;
import com.aula1.crud.Model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {
    private final ProdutoRepository produtoRepository;

    @Autowired
    public ProdutoService(ProdutoRepository produtoRepository){
        this.produtoRepository = produtoRepository;
    }

    public Produto CreateProduto(Produto produto){
        return produtoRepository.save(produto);
    }

    public List<Produto> findAllProduto(){
        return produtoRepository.findAll();
    }

    public Optional<Produto> findProdutoById(Long id){
        return produtoRepository.findById(id);
    }

    public Produto updateProduto(Long id, Produto produtoDetails){
        Produto produto = produtoRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Produto not found with id: " + id));
        produto.setNome(produtoDetails.getNome());
        produto.setCategoria(produtoDetails.getCategoria());
        produto.setDescricao(produtoDetails.getDescricao());
        produto.setPreco(produtoDetails.getPreco());
        produto.setStatus(produtoDetails.getStatus());
        return produtoRepository.save(produto);
    }

    public void deleteProduto(Long id){
        Produto produto = produtoRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Produto not found with id: " + id));
        produtoRepository.delete(produto);
    }
}
