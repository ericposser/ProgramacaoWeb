package Atividade.crud.Service;

import Atividade.crud.Model.Cliente;
import Atividade.crud.Model.Produto;
import Atividade.crud.Repository.ClienteRepository;
import com.aula1.crud.Exception.ResourceNotFoundException;
import com.aula1.crud.Model.User;
import com.aula1.crud.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClienteService {
    private final ClienteRepository clienteRepository;

    @Autowired
    public ClienteService(ClienteRepository clienteRepository){
        this.clienteRepository = clienteRepository;
    }

    public Cliente CreateCliente(Cliente cliente){
        return clienteRepository.save(cliente);
    }

    public List<Cliente> findAllCliente(){
        return clienteRepository.findAll();
    }

    public Optional<Cliente> findClienteById(Long id){
        return clienteRepository.findById(id);
    }

    public Cliente updateCliente(Long id, Cliente clienteDetails){
        Cliente cliente = clienteRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Cliente not found with id: " + id));
        cliente.setNome(clienteDetails.getNome());
        cliente.setPreferenciaPagamento(clienteDetails.getPreferenciaPagamento());
        cliente.setEndereco(clienteDetails.getEndereco());
        cliente.setDetalhesContato(clienteDetails.getDetalhesContato());
        return clienteRepository.save(cliente);
    }

    public void deleteCliente(Long id){
        Cliente cliente = clienteRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Cliente not found with id: " + id));
        clienteRepository.delete(cliente);
    }
}
