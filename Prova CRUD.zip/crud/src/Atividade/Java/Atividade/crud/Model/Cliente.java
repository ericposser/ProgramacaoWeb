package Atividade.crud.Model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter
@Setter
public class Cliente {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String nome;

    private String detalhesContato;

    private String endereco;

    private String preferenciaPagamento;

    @OneToOne(mappedBy = "cliente", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private Carrinho carrinho;

    public Cliente(String nome, String detalhesContato, String endereco, String preferenciaPagamento, Carrinho carrinho) {
        this.nome = nome;
        this.detalhesContato = detalhesContato;
        this.endereco = endereco;
        this.preferenciaPagamento = preferenciaPagamento;
        this.carrinho = carrinho;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDetalhesContato() {
        return detalhesContato;
    }

    public void setDetalhesContato(String detalhesContato) {
        this.detalhesContato = detalhesContato;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getPreferenciaPagamento() {
        return preferenciaPagamento;
    }

    public void setPreferenciaPagamento(String preferenciaPagamento) {
        this.preferenciaPagamento = preferenciaPagamento;
    }

    public Carrinho getCarrinho() {
        return carrinho;
    }

    public void setCarrinho(Carrinho carrinho) {
        this.carrinho = carrinho;
    }
}
