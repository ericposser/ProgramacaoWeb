package Atividade.crud.Model;

import jakarta.persistence.*;

@Entity
public class Pagamento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String metodoPagamento;

    private float valor;

    private String status;

    @OneToOne(mappedBy = "pagamento", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private Pedido pagamentoPedido;

    public Pagamento(String metodoPagamento, float valor, String status, Pedido pagamentoPedido) {
        this.metodoPagamento = metodoPagamento;
        this.valor = valor;
        this.status = status;
        this.pagamentoPedido = pagamentoPedido;
    }

    public String getMetodoPagamento() {
        return metodoPagamento;
    }

    public void setMetodoPagamento(String metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Pedido getPagamentoPedido() {
        return pagamentoPedido;
    }

    public void setPagamentoPedido(Pedido pagamentoPedido) {
        this.pagamentoPedido = pagamentoPedido;
    }
}
