package Atividade.crud.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Admin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String nome;

    private String senha;

    private String funcao;

    private String detalhesContato;

    public Admin(String nome, String senha, String funcao, String detalhesContato) {
        this.nome = nome;
        this.senha = senha;
        this.funcao = funcao;
        this.detalhesContato = detalhesContato;
    }

    public String getNome() {
        return nome;
    }

    public String getSenha() {
        return senha;
    }

    public String getFuncao() {
        return funcao;
    }

    public String getDetalhesContato() {
        return detalhesContato;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public void setDetalhesContato(String detalhesContato) {
        this.detalhesContato = detalhesContato;
    }
}
