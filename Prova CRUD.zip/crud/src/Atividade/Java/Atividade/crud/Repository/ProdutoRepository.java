package Atividade.crud.Repository;

import Atividade.crud.Model.Cliente;
import Atividade.crud.Model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {

}
