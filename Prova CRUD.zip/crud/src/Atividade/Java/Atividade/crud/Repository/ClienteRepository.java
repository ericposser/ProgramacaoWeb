package Atividade.crud.Repository;

import Atividade.crud.Model.Cliente;
import com.aula1.crud.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {

}
