package Atividade.crud.Controller;

import Atividade.crud.Model.Cliente;
import Atividade.crud.Model.Produto;
import Atividade.crud.Service.ClienteService;
import Atividade.crud.Service.ProdutoService;
import com.aula1.crud.Exception.ResourceNotFoundException;
import com.aula1.crud.Model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/produto")
public class ProdutoController {
    private final ProdutoService produtoService;

    @Autowired
    public ProdutoController(ProdutoService produtoService){
        this.produtoService = produtoService;
    }

    @PostMapping
    public ResponseEntity<Produto> CreateProduto(@RequestBody Produto produto){
        Produto newProduto = produtoService.CreateProduto(produto);
        return ResponseEntity.ok(newProduto);
    }

    @GetMapping
    public  ResponseEntity<List<Produto>> getAllProdutos(){
        List<Produto> produtos = produtoService.findAllProduto();
        return ResponseEntity.ok(produtos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Produto> getProdutoById(@PathVariable Long id){
        Produto produto = produtoService.findProdutoById(id).orElseThrow(() -> new ResourceNotFoundException("Produto not found with id: " + id));
        return ResponseEntity.ok(produto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Produto> updateProduto(@PathVariable Long id, @RequestBody Produto produtoDetails) {
        Produto updatedProduto = produtoService.updateProduto(id, produtoDetails);
        return ResponseEntity.ok(updatedProduto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduto(@PathVariable Long id){
        produtoService.deleteProduto(id);
        return ResponseEntity.ok().build();
    }
}
