package Atividade.crud.Controller;

import Atividade.crud.Model.Cliente;
import Atividade.crud.Model.Produto;
import Atividade.crud.Service.ClienteService;
import com.aula1.crud.Exception.ResourceNotFoundException;
import com.aula1.crud.Model.User;
import com.aula1.crud.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cliente")
public class ClienteController {
    private final ClienteService clienteService;

    @Autowired
    public ClienteController(ClienteService clienteService){
        this.clienteService = clienteService;
    }

    @PostMapping
    public ResponseEntity<Cliente> CreateCliente(@RequestBody Cliente cliente){
        Cliente newCliente = clienteService.CreateCliente(cliente);
        return ResponseEntity.ok(newCliente);
    }

    @GetMapping
    public  ResponseEntity<List<Cliente>> getAllClientes(){
        List<Cliente> clientes = clienteService.findAllCliente();
        return ResponseEntity.ok(clientes);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cliente> getClienteById(@PathVariable Long id){
        Cliente cliente = clienteService.findClienteById(id).orElseThrow(() -> new ResourceNotFoundException("Cliente not found with id: " + id));
        return ResponseEntity.ok(cliente);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Cliente> updateCliente(@PathVariable Long id, @RequestBody Cliente clienteDetails) {
        Cliente updatedCliente = clienteService.updateCliente(id, clienteDetails);
        return ResponseEntity.ok(updatedCliente);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCliente(@PathVariable Long id){
        clienteService.deleteCliente(id);
        return ResponseEntity.ok().build();
    }
}
