package com.aula1.crud.repository;

import com.aula1.crud.Model.Phone;
import com.aula1.crud.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface UserRepository extends JpaRepository<User, Long> {
    List<User> findByName(String name);

    User findByEmail(String email);

    @Query(value = "SELECT * FROM user WHERE name LIKE CONCAT('%', ?1, '%')", nativeQuery = true)
    User findByAlgumaCoisaName(String name);

}
