package com.aula1.crud.Model;

import jakarta.persistence.Embeddable;

import java.io.Serializable;

@Embeddable
public class Address implements Serializable {
    private String street;
    private String city;
    private String state;
    private String zipCode;
    // construtores, getters e setters omitidos por brevidade
}
