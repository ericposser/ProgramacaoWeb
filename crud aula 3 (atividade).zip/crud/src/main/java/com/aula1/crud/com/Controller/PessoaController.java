package com.aula1.crud.com.Controller;

import com.aula1.crud.com.Model.Pessoa;
import com.aula1.crud.com.repository.PessoaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping(path = "/pessoa")
public class PessoaController {
    @Autowired
    private PessoaRepository repository;

    @GetMapping
    public @ResponseBody List<Pessoa> listarPessoa(){
        return repository.findAll();
    }

    //insert
    @PostMapping
    public @ResponseBody String salvarPessoa(@RequestBody Pessoa pessoa) {
        repository.save(pessoa);
        return "saved";
    }
}
