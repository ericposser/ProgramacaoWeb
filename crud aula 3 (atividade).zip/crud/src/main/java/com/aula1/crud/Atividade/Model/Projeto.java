package com.aula1.crud.Atividade.Model;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Projeto {
    @Id
    private int Pnumero;
    private String projNome;

    private String projLocal;

    @ManyToOne
    @JoinColumn(name = "departamento_id", nullable = true)
    private Departamento projetoDepartamento;

    @OneToMany(mappedBy = "tProjeto", cascade = CascadeType.ALL)
    private List<Trabalha_em> projetosP;

}
