package com.aula1.crud.Atividade.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.util.Date;

@Entity
public class Dependente {
    @Id
    private String nome;
    private String sexo;
    private Date dataNasci;

    private String parentesco;

    @ManyToOne
    @JoinColumn(name = "Fcpf", nullable = true)
    @Id
    private Funcionario funcionarioDep;

}
