package com.aula1.crud.Atividade.Repository;

public interface DependenteRepository {
}
