package com.aula1.crud.Atividade.Model;

public class Nome {
    private String Pnome;
    private String Minicial;
    private String  Unome;
}
