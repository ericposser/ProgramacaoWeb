package com.aula1.crud.Atividade.Model;

import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

public class Localizacao_dep {

    @Id
    @ManyToOne
    @JoinColumn(name = "Dnumero", nullable = false)
    private Departamento departamento;

    @Id
    @ManyToOne
    @JoinColumn(name = "Dlocal", nullable = false)
    private Departamento localizacaoD;
}
