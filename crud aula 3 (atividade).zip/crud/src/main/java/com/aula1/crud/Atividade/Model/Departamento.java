package com.aula1.crud.Atividade.Model;

import jakarta.persistence.*;

import java.util.Date;
import java.util.List;

@Entity
public class Departamento {
    @Id
    private int Dnumero;
    private String  Dnome;

    private List<String> localizacoes;

    private Date data_inicio_gerente;

    @OneToMany(mappedBy = "projetoDepartamento", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Projeto> projetosDep;

    @OneToMany(mappedBy = "departamentoFuncionario", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Funcionario> funcionarios;

}
