package com.aula1.crud.Atividade.Model;

import jakarta.persistence.*;

import java.util.Date;
import java.util.List;

@Entity
public class Departamento {
    @Id
    private int Dnumero;
    private String  Dnome;

    private Date data_inicio_gerente;

    @OneToMany(mappedBy = "projetoDepartamento", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Projeto> projetosDep;

    @OneToMany(mappedBy = "departamentoFuncionario", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Funcionario> funcionarios;

    @OneToMany(mappedBy = "departamento", cascade = CascadeType.ALL)
    private List<Localizacao_dep> NumeroD;

    @OneToMany(mappedBy = "localizacaoD", cascade = CascadeType.ALL)
    private List<Localizacao_dep> localizaoD;
}
