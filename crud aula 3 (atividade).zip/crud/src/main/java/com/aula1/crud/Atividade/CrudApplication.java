package com.aula1.crud.Atividade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(com.aula1.crud.Atividade.CrudApplication.class, args);
    }

}