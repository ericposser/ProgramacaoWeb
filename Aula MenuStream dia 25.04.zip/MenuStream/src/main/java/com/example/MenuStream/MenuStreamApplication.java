package com.example.MenuStream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MenuStreamApplication {

	public static void main(String[] args) {
		SpringApplication.run(MenuStreamApplication.class, args);
	}

}
