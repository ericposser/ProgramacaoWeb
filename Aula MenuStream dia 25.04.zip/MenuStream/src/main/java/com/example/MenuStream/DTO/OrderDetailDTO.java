package com.example.MenuStream.DTO;

import lombok.Data;

@Data
public class OrderDetailDTO {
    private Long productId;
    private Integer quantity;
}
