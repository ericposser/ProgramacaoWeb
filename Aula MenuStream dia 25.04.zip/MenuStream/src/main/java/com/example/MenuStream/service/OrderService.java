package com.example.MenuStream.service;

import com.example.MenuStream.DTO.OrderDTO;
import com.example.MenuStream.DTO.OrderDetailDTO;
import com.example.MenuStream.model.Customer;
import com.example.MenuStream.model.Order;
import com.example.MenuStream.model.OrderDetail;
import com.example.MenuStream.model.Product;
import com.example.MenuStream.repository.CustomerRepository;
import com.example.MenuStream.repository.OrderRepository;
import com.example.MenuStream.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private CustomerRepository customerRepository;

    public Order saveOrder(OrderDTO orderDTO){
        Customer customer = customerRepository.findById(orderDTO.getCustomerId())
                .orElseThrow(() -> new RuntimeException("Customer not found,,"));

        Order order = new Order();
        order.setCustomer(customer);
        order.setTotalAmount(orderDTO.getTotalAmount());
        order.setStatus(orderDTO.getStatus());
        order.setOrderDate(orderDTO.getOrderDate());
        order.setFulfillmentDate(orderDTO.getFulfillmentDate());

        for(OrderDetailDTO detail : orderDTO.getOrderDetails()){
            Product product = productRepository.findById(detail.getProductId())
                    .orElseThrow(() -> new RuntimeException("Product not found,,"));

            OrderDetail orderDetail = new OrderDetail();
            orderDetail.setProduct(product);
            orderDetail.setQuantity(detail.getQuantity());
            order.addOrderDetail(orderDetail);
        }

        return orderRepository.save(order);
    }

    public List<Order> getAllOrders(){
        return orderRepository.findAll();
    }

}
